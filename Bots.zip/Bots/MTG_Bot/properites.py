CARD PROPERTIES
name
multiverse_id
layout
names
mana_cost
cmc
colors
color_identity
type
supertypes
subtypes
rarity
text
flavor
artist
number
power
toughness
loyalty
variations
watermark
border
timeshifted
hand
life
reserved
release_date
starter
rulings
foreign_names
printings
original_text
original_type
legalities
source
image_url
set
set_name
id

self.props = [self.card.name, self.card.multiverse_id, self.card.layout, self.card.names, self.card.mana_cost, self.card.cmc, self.card.colors, self.card.color_identity, self.card.type, self.card.rarity, self.card.text, self.card.flavor, self.card.artist, self.card.number, self.card.power, self.card.toughness, self.card.loyalty, self.card.variations, self.card.watermark, self.card.border, self.card.timeshifted, self.card.hand, self.card.life, self.card.release_date, self.card.set, self.card.set_name, self.card.id]
    self.propsString = ["name," "multiverse_id", "layout", "names", "mana_cost", "cmc, colors", "color_identity", "type", "supertypes", "subtypes" "rarity", "text", "flavor", "artist", "number", "power", "toughness", "loyalty," "variations", "watermark", "border", "timeshifted", "hand", "life", "reserved", "release_date", "starter", "rulings", "foreign_names", "printings", "original_text", "original_type", "legalities", "source", "set", "set_name", "id"]





SET PROPERTIES
code
name
gatherer_code
old_code
magic_cards_info_code
release_date
border
type
block
online_only
booster
mkm_id
mkm_name