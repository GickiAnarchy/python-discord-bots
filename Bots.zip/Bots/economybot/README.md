# EconomyBot

An Economy based Discord bot.

Features:
  -User money can be in 2 separate containers. WALLET and BANK.
    <deposit amount>
    <withdraw amount>
  -Users can attempt to steal from another users WALLET
    <steal @mentionedUser>
  -Users can bet on a coin flip.
    <flip (Heads or Tails) amount>


Upcoming features:
  -Roulette
  -Slot Machines 
    betting amounts:(10,50,100,500)
  -Bank Transfers between users